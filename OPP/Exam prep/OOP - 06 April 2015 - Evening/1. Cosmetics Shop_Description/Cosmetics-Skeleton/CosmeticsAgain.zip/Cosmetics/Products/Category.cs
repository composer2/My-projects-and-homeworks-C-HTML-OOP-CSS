﻿using Cosmetics.Common;
using Cosmetics.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cosmetics.Products
{
    public class Category : ICategory
    {
        private string name;
        private readonly ICollection<IProduct> product;
        private const int minNameLength = 2;
        private const int maxNameLength = 15;

        public Category(string name)
        {
            this.Name = name;
            this.product = new List<IProduct>();
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            private set
            {
                Validator.CheckIfStringIsNullOrEmpty(value, string.Format(GlobalErrorMessages.StringCannotBeNullOrEmpty, "Category name"));
                Validator.CheckIfStringLengthIsValid(value, maxNameLength, minNameLength, string.Format(GlobalErrorMessages.InvalidStringLength, "Category name", minNameLength, maxNameLength));
                this.name = value;
            }
        }

        public void AddCosmetics(IProduct cosmetics)
        {
            Validator.CheckIfNull(cosmetics, string.Format(GlobalErrorMessages.ObjectCannotBeNull, "Cosmetics to add to category"));
            this.product.Add(cosmetics);
            this.product.Add(cosmetics);
        }

        public void RemoveCosmetics(IProduct cosmetics)
        {
            Validator.CheckIfNull(cosmetics, string.Format(GlobalErrorMessages.ObjectCannotBeNull, "Cosmetics to remove from category"));
            if (!this.product.Contains(cosmetics))
            {
                throw new InvalidOperationException(string.Format("Product {0} does not exist in category {1}!", cosmetics.Name, this.Name));
            }
            this.product.Remove(cosmetics);     
        }
        public string Print()
        {
            var categoryString = string.Format("{0} category - {1} {2} in total", this.Name, this.product.Count, this.product.Count != 1 ? "products" : "product");

            var result = new StringBuilder();
            result.AppendLine(categoryString);

            var sortedProducts =
                this.product
                    .OrderBy(pr => pr.Brand)
                    .ThenByDescending(pr => pr.Price);

            foreach (var product in sortedProducts)
            {
                result.AppendLine(product.Print());
            }

            return result.ToString().Trim();
        }

    }
}

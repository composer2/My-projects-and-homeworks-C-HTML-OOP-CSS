﻿using Cosmetics.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cosmetics.Common;

namespace Cosmetics.Products
{
    public abstract class Product : IProduct
    {
        private const int minBrandLength = 2;
        private const int minNameLength = 3;
        private const int maxNameOrBrandLength = 10;
        private const string ProductName = "Product name";
        private const string ProductBrand = "Product brand";

        private string brand;
        private string name;
        
        

        public Product(string name, string brand, decimal price, GenderType gender)
        {
            this.Name = name;
            this.Brand = brand;
            this.Price = price;
            this.Gender = gender;
        }

        public string Brand
        {
            get
            {
                return this.brand;
            }
            private set
            {
                Validator.CheckIfStringIsNullOrEmpty(value, string.Format(GlobalErrorMessages.StringCannotBeNullOrEmpty, ProductBrand));
                Validator.CheckIfStringLengthIsValid(value, maxNameOrBrandLength, minBrandLength, string.Format(GlobalErrorMessages.InvalidStringLength, ProductBrand, minBrandLength, maxNameOrBrandLength));
                this.brand = value;
            }
        }


        public string Name
        {
            get
            {
                return this.name;
            }
            private set
            {
                Validator.CheckIfStringIsNullOrEmpty(value, string.Format(GlobalErrorMessages.StringCannotBeNullOrEmpty, ProductName));
                Validator.CheckIfStringLengthIsValid(value, maxNameOrBrandLength, minNameLength, string.Format(GlobalErrorMessages.InvalidStringLength, ProductName, minNameLength, maxNameOrBrandLength));
                this.name = value;
            }
        }

        public GenderType Gender { get; private set; }
        public decimal Price { get; protected set; }

        public virtual string Print()
        {
            var result = new StringBuilder();
            result.AppendLine(string.Format("- {0} - {1}:", this.Brand, this.Name));
            result.AppendLine(string.Format("  * Price: ${0}", this.Price));
            result.Append(string.Format("  * For gender: {0}", this.Gender));
            return result.ToString();
        }
    }
}

﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum IntercoolerType
    {
        NotSet = 0,
        AirToLiquidIntercooler,
        ChargeAirIntercooler
    }
}

﻿using Dealership.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dealership.Common.Enums;
using Dealership.Common;

namespace Dealership.Models
{
    public class User : IUser
    {
        private int addedCars = 0;
        private string firstName;
        private string lastName;
        private string password;
        private Role role;
        private string username;
        private IList<IVehicle> vehicles = new List<IVehicle>();
        private bool isLogged = false;
        private string roleAsString;

        public User(string username, string firstName, string lastName, string password, string roleAsString)
        {
            this.Username = username;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Password = password;
            this.roleAsString = roleAsString;
            this.Role = ReturnRole(roleAsString);
        }

        //TODO: Fix this

        public string FirstName
        {
            get
            {
                return this.firstName;
            }
            protected set
            {
                Validator.ValidateIntRange(value.Length, Constants.MinNameLength, Constants.MaxNameLength, String.Format(Constants.StringMustBeBetweenMinAndMax, "Firstname", Constants.MinNameLength, Constants.MaxNameLength));
                this.firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return this.lastName;
            }
            protected set
            {
                Validator.ValidateIntRange(value.Length, Constants.MinNameLength, Constants.MaxNameLength, String.Format(Constants.StringMustBeBetweenMinAndMax, "Lastname", Constants.MinNameLength, Constants.MaxNameLength));
                this.lastName = value;
            }
        }

        public string Password
        {
            get
            {
                return this.password;
            }
            protected set
            {
                Validator.ValidateIntRange(value.Length, Constants.MinPasswordLength, Constants.MaxPasswordLength, String.Format(Constants.StringMustBeBetweenMinAndMax, "Password", Constants.MinPasswordLength, Constants.MaxPasswordLength));
                this.password = value;
            }
        }

        public Role Role
        {
            get
            {
                return this.role;
            }
            protected set
            {
                this.role = value;
            }

        }

        public string Username
        {
            get
            {
                return this.username;
            }
            protected set
            {
                Validator.ValidateIntRange(value.Length, Constants.MinNameLength, Constants.MaxNameLength, String.Format(Constants.StringMustBeBetweenMinAndMax, "Username", Constants.MinNameLength, Constants.MaxNameLength));
                Validator.ValidateSymbols(value, Constants.UsernamePattern, string.Format(Constants.InvalidSymbols, "Username"));
                this.username = value;
            }
        }

        public IList<IVehicle> Vehicles
        {
            get
            {
                return this.vehicles;
            }
        }

        public void AddComment(IComment commentToAdd, IVehicle vehicleToAddComment)
        {
            Validator.ValidateNull(commentToAdd, Constants.CommentCannotBeNull);
            Validator.ValidateNull(vehicleToAddComment, Constants.VehicleCannotBeNull);
            vehicleToAddComment.Comments.Add(commentToAdd);
        }

        public void AddVehicle(IVehicle vehicle)
        {
            Validator.ValidateNull(vehicle, Constants.VehicleCannotBeNull);
            if (Role == Role.Admin)
            {
                throw new ArgumentException(Constants.AdminCannotAddVehicles);
            }

            if (Role == Role.Normal && addedCars >= Constants.MaxVehiclesToAdd)
            {
                 throw new ArgumentException(string.Format(Constants.NotAnVipUserVehiclesAdd, Constants.MaxVehiclesToAdd));
            }
            else
            {
                this.vehicles.Add(vehicle);
                addedCars++;
            }
        }

        public string PrintVehicles()
        {
            StringBuilder info = new StringBuilder();
            int counter = 1;
            info.AppendLine(string.Format("--USER {0}--", this.username));
            if (vehicles.Count > 0)
            {
                foreach (var vehicle in this.vehicles)
                {
                    info.AppendLine(string.Format("{0}. {1}:", counter, vehicle.Type.ToString()));
                    info.AppendLine(string.Format("  Make: {0}", vehicle.Make));
                    info.AppendLine(string.Format("  Model: {0}", vehicle.Model));
                    info.AppendLine(string.Format("  Wheels: {0}", vehicle.Wheels));
                    info.AppendLine(string.Format("  Price: ${0}", vehicle.Price));
                    if (vehicle.Type == VehicleType.Car)
                    {
                        Car car = (Car)vehicle;
                        info.AppendLine(string.Format("  Seats: {0}", car.Seats));
                    }
                    else if (vehicle.Type == VehicleType.Truck)
                    {
                        Truck truck = (Truck)vehicle;
                        info.AppendLine(string.Format("  Weight Capacity: {0}t", truck.WeightCapacity));
                    }
                    else
                    {
                        Motorcycle motorcycle = (Motorcycle)vehicle;
                        info.AppendLine(string.Format("  Category: {0}", motorcycle.Category));
                    }
                    if (vehicle.Comments.Count == 0)
                    {
                        info.AppendLine("    --NO COMMENTS--");
                    }
                    else
                    {
                        info.AppendLine("    --COMMENTS--");
                        foreach (var comment in vehicle.Comments)
                        {
                            info.AppendLine("    ----------");
                            info.AppendLine(string.Format("    {0}", comment.Content));
                            info.AppendLine(string.Format("      User: {0}", comment.Author));
                            info.AppendLine("    ----------");
                        }
                        info.AppendLine("    --COMMENTS--");
                    }
                    counter++;
                }
            }
            else
            {
                info.AppendLine("--NO VEHICLES--");
            }
            info.Length = info.Length - 2;
            return info.ToString();
        }

        public void RemoveComment(IComment commentToRemove, IVehicle vehicleToRemoveComment)
        {
            Validator.ValidateNull(commentToRemove, Constants.CommentCannotBeNull);
            Validator.ValidateNull(vehicleToRemoveComment, Constants.VehicleCannotBeNull);
            if (commentToRemove.Author == this.username)
            {
                vehicleToRemoveComment.Comments.Remove(commentToRemove);
            }
            else
            {
                throw new ArgumentException(Constants.YouAreNotTheAuthor);
            }
        }

        public void RemoveVehicle(IVehicle vehicle)
        {
            Validator.ValidateNull(vehicle, Constants.VehicleCannotBeNull);
            this.vehicles.Remove(vehicle);
        }

        public override string ToString()
        {
            return string.Format("Username: {0}, FullName: {1} {2}, Role: {3}", this.Username, this.FirstName, this.LastName, this.Role);
        }

        private Role ReturnRole(string role)
        {
            if (role == "normal" || role == "Normal")
            {
                return Role.Normal;
            }
            else if (role == "Admin" || role == "admin")
            {
                return Role.Admin;
            }
            else
            {
                return Role.VIP;
            }
        }
    }
}

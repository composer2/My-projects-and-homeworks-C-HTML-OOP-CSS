﻿using Dealership.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dealership.Common;
using Dealership.Common.Enums;

namespace Dealership.Models
{
    public class Car : Vehicle, ICar
    {
        private int seats;

        public Car(string make, string model, decimal price, int seats)
        {
            this.Make = make;
            this.Model = model;
            this.Price = price;
            this.Seats = seats;
            this.Type = VehicleType.Car;
            this.Wheels = 4;
        }

        public int Seats
        {
            get
            {
                return this.seats;
            }
            protected set
            {
                Validator.ValidateIntRange(value, Constants.MinSeats, Constants.MaxSeats, string.Format(Constants.NumberMustBeBetweenMinAndMax, "Seats", Constants.MinSeats, Constants.MaxSeats));
                this.seats = value;
            }
        }
        //public override string UseInPrinting()
        //{
        //    return string.Format("Seats: {0}");
        //}
    }
}

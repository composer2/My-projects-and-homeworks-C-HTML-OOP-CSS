﻿using Dealership.Contracts;
using Dealership.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dealership.Common.Enums;

namespace Dealership.Models
{
    public abstract class Vehicle : IVehicle
    {
        private string make;
        private string model;
        private decimal price;
        private VehicleType type;
        private int wheels;
        private IList<IComment> comments = new List<IComment>();

        public IList<IComment> Comments
        {
            get
            {
                return this.comments;
            }
        }


        public string Make
        {
            get
            {
                return this.make;
            }
            protected set
            {
                Validator.ValidateIntRange(value.Length, Constants.MinMakeLength, Constants.MaxMakeLength, string.Format(Constants.StringMustBeBetweenMinAndMax, "Make", Constants.MinMakeLength, Constants.MaxMakeLength));
                this.make = value;
            }
        }

        public string Model
        {
            get
            {
                return this.model;
            }
            protected set
            {
                Validator.ValidateIntRange(value.Length, Constants.MinModelLength, Constants.MaxModelLength, string.Format(Constants.StringMustBeBetweenMinAndMax, "Model", Constants.MinMakeLength, Constants.MaxMakeLength));
                this.model = value;
            }
        }

        public decimal Price
        {
            get
            {
                return this.price;
            }
            protected set
            {
                Validator.ValidateDecimalRange(value, Constants.MinPrice, Constants.MaxPrice, string.Format(Constants.NumberMustBeBetweenMinAndMax, "Price", Constants.MinPrice, Constants.MaxPrice));
                this.price = value;
            }
        }

        public VehicleType Type
        {
            get
            {
                return this.type;
            }          
            protected set
            {
                this.type = value;
            }  
        }

        public int Wheels
        {
            //TODO: Implement Validator
            get
            {
                return this.wheels;
            }
            protected set
            {
                this.wheels = value;
            }
        }


       //public virtual string UseInPrinting()
       //{
       //    return "Error";
       //}
    }
}

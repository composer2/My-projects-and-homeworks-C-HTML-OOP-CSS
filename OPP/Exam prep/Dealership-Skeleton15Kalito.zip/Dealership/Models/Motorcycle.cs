﻿using Dealership.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dealership.Common;
using Dealership.Common.Enums;

namespace Dealership.Models
{
    class Motorcycle : Vehicle, IMotorcycle
    {
        private string categoty;

        public Motorcycle(string make, string model, decimal price, string category)
        {
            this.Make = make;
            this.Model = model;
            this.Price = price;
            this.Category = category;
            this.Type = VehicleType.Motorcycle;
            this.Wheels = 2;
        }

        public string Category
        {
            get
            {
                return this.categoty;
            }
            protected set
            {
                Validator.ValidateIntRange(value.Length, Constants.MinCategoryLength, Constants.MaxCategoryLength, String.Format(Constants.StringMustBeBetweenMinAndMax, "Category", Constants.MinCategoryLength, Constants.MaxCategoryLength));
                this.categoty = value;
            }
        }
    }
}

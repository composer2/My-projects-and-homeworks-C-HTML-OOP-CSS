﻿using Dealership.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dealership.Common;
using Dealership.Common.Enums;

namespace Dealership.Models
{
    public class Truck : Vehicle, ITruck
    {
        private int weightCapacity;

        public Truck(string make, string model, decimal price, int weightCapacity)
        {
            this.Make = make;
            this.Model = model;
            this.Price = price;
            this.WeightCapacity = weightCapacity;
            this.Type = VehicleType.Truck;
            this.Wheels = 8;
        }

        public int WeightCapacity
        {
            get
            {
                return this.weightCapacity;
            }
            protected set
            {
                Validator.ValidateIntRange(value, Constants.MinCapacity, Constants.MaxCapacity, string.Format(Constants.NumberMustBeBetweenMinAndMax, "Weight capacity", Constants.MinCapacity, Constants.MaxCapacity));
                this.weightCapacity = value;
            }
        }
    }
}
